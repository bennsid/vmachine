<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sbsa_vmachine";
session_start();
      // if(isset($_SESSION['currentUser']))
      // {
      //   session_unset();
      //   session_destroy();
      // }

      // Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);


// if($_SERVER["REQUEST_METHOD"] == "POST")
// {

  $myusername= "assessment";//mysqli_real_escape_string($conn,$_POST['username']); 
  $mypassword= "test123";//mysqli_real_escape_string($conn,$_POST['password']); 

  $sql="SELECT * FROM users WHERE username='$myusername' and password='$mypassword'";
  $result=mysqli_query($conn,$sql);
  $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
                //$active=$row['active'];
  $count=mysqli_num_rows($result);



  $result = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_assoc($result))//We are retrieveing the User ID from the users table
                {

                 
                  $_SESSION["currentUser"] = $row['userID'];
                 
                }
                
                if($count==1)
                {
                  
                  //echo"<script> alert('Logged in');</script>";
                  Header("Location: prodManagement.php");
                }
                else 
                {
                  $message = "wrong answer";
                Header("Location: index.php");
                 // echo "<script type='text/javascript'>alert('$message');</script>";

                }
              // }
              ?>