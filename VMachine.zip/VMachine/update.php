<?php
        $prodID = $_POST['id'];
        $hostname = "localhost";
        $username = "root";
        $password = "";
        $databaseName = "sbsa_vmachine";

        $connect = mysqli_connect($hostname, $username, $password, $databaseName);
        $query = "UPDATE products SET quantity = quantity-1 WHERE id ='" . $prodID . "'" ;
        $result1 = mysqli_query($connect, $query);
        //$result2 = mysqli_query($connect, $query);
        $dataRow = "";
?> 