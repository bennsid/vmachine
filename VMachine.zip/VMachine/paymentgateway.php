

<html lang="en">

<head>
  <meta charset="utf-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <style>
  /* Center the loader */
  #loader {
    position: absolute;
    left: 50%;
    top: 50%;
    z-index: 1;
    width: 150px;
    height: 150px;
    margin: -75px 0 0 -75px;
    border: 16px solid #f3f3f3;
    border-radius: 50%;
    border-top: 16px solid #3498db;
    width: 120px;
    height: 120px;
    -webkit-animation: spin 2s linear infinite;
    animation: spin 2s linear infinite;
  }

  @-webkit-keyframes spin {
    0% { -webkit-transform: rotate(0deg); }
    100% { -webkit-transform: rotate(360deg); }
  }

  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }

  /* Add animation to "page content" */
  .animate-bottom {
    position: relative;
    -webkit-animation-name: animatebottom;
    -webkit-animation-duration: 1s;
    animation-name: animatebottom;
    animation-duration: 1s
  }

  @-webkit-keyframes animatebottom {
    from { bottom:-100px; opacity:0 } 
    to { bottom:0px; opacity:1 }
  }

  @keyframes animatebottom { 
    from{ bottom:-100px; opacity:0 } 
    to{ bottom:0; opacity:1 }
  }

  #myDiv {
    display: none;
    text-align: center;
  }
</style>

</head>
<body onload="myFunction()">
  <div id="loader"></div>
  <div  style="display:none;" id="myDiv" class="animate-bottom">

    <div class="page-header">
      <h1>Assessment Vending Machine <small>Your 1 stop shop</small></h1>
    </div>  

    <script type="text/javascript">
      $(window).on('load',function(){
        $('#modal').modal('show');
      });
    </script>

    <nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand" href="index.php">Back to Products</a>
        </div>
        <ul class="nav navbar-nav">
        </ul>
      </div>
    </nav>


    <div class="card">
      <div class="col-sm-5 text-center">
        <div class="card">
          <div class="card-body">
            <?php
            $productID = $_GET["id"];
            $hostname = "localhost";
            $username = "root";
            $password = "";
            $databaseName = "sbsa_vmachine";

            $connect = mysqli_connect($hostname, $username, $password, $databaseName);

            $query = "SELECT * FROM `products` WHERE ID='" . $productID . "'" ;
            $result1 = mysqli_query($connect, $query);
            $result2 = mysqli_query($connect, $query);
            $dataRow = "";


            while($row2 = mysqli_fetch_array($result2))
            {
              ?>
              <h1 class="font-weight-bold mb-3"><u><?php echo $row2[1] ?></u></h1>
              <p><img src= <?php echo $row2[5] ?> alt="..."></p>

            </div>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="card">
            <div class="card-body">
              <h1 class="card-title"><u>Product Details</u></h1>
              <h3 class="card-title">Product Descr: <?php echo $row2[2] ?></h3>
              <h3 class="card-text">Product Price: R<?php echo $row2[3] ?></h3>
              <h3 class="card-text">Product Quant: <?php echo $row2[4] ?></h3>
              <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#Modal">Insert Money</a>
            </div>
          </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title" id="exampleModalLabel">Amount Due: R<?php echo $row2[3] ?></h1>
                <p id="change"></p>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <p>Please select value to pay with</p>
                <button type="button" id="fiftyC" class="btn btn-primary btn-lg" value="0.50" onclick="myFunction(this)">R0.50</button>
                <button type="button" id="OneR" class="btn btn-primary btn-lg" value="1.00" onclick="myFunction(this)">R1.00</button>
                <button type="button" id="TwoR" class="btn btn-primary btn-lg" value="2.00" onclick="myFunction(this)">R2.00</button>
                <button type="button" id="ThreeR"class="btn btn-primary btn-lg" value="5.00" onclick="myFunction(this)">R5.00</button>

              </div>
              <div class="modal-footer">
        </div>
      </div>
    </div>
  </div>

  <script type="text/javascript">
    var productID = "<?php echo $row2[0] ?>";
    var prodAmountDue = "<?php echo $row2[3] ?>";
    var change = 0;
    var total = 0;

    $("button").click(function() {
      var btnValue = $(this).val();
      total = total + +btnValue;
    //alert(total);

    change = prodAmountDue - total;
    //alert(change);

    if (change<=0) {
      swal("Payment Complete!", "Thank you for honoring you payment \n Collect your item and change of R" +change , "success");
      $('#Modal').click(function() {
        $('#Modal').modal('hide');
      });

      $.ajax({
        data: 'id=' + productID,
        url: 'update.php',
        method: 'POST', 
        success: function() {
                //location.reload();
              }
            });
      reloadPage();
    }
    else
    {
      swal("Payment Incomplete!", "Outstanding amount of R" + change  , "error");
      document.getElementById("change").innerHTML = "Outstanding Amount R" + change;
    }


    function reloadPage()
    {
      setTimeout(function () {
        window.location = "index.php";
      }, 8000);
    }

  });
</script>
</div><?php } ?>

</div>

<script>//This is for the loader
var myVar;
function myFunction() {
  myVar = setTimeout(showPage, 1000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>

</body>
</html>