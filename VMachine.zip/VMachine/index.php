<script type="text/javascript">
    setTimeout(function() {
      location.reload();
  }, 30000);
</script>

<html lang="en">
<head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="30"; URL=index.php"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body onload="myFunction()">

    <div class="page-header">
        <h1>Assessment Vending Machine <small>Your 1 stop shop</small></h1>
    </div>  
    <nav class="navbar navbar-default" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">VMachine</a>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#loginModal" role="button" class="" data-toggle="modal">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <div class="container-fluid">
        <div id="loginModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Login</h3>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <div class="modal-body">
                        <form class="form" action = "login.php" role="form" autocomplete="off" id="formLogin" novalidate="" method="POST">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control form-control-lg" name="username" id="username" required="">
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control form-control-lg" id="password" name="password" required="" autocomplete="new-password">
                                <div class="invalid-feedback"></div>
                            </div>
                            <div class="form-group py-4">
                                <button class="btn btn-outline-secondary btn-lg" data-dismiss="modal" aria-hidden="true">Cancel</button>
                                <button type="submit" class="btn btn-success btn-lg float-right" id="btnLogin">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <?php
        $hostname = "localhost";
        $username = "root";
        $password = "";
        $databaseName = "sbsa_vmachine";

        $connect = mysqli_connect($hostname, $username, $password, $databaseName);
        $query = "SELECT * FROM `products` WHERE Quantity>'0'";
        $result1 = mysqli_query($connect, $query);
        $result2 = mysqli_query($connect, $query);
        $dataRow = "";
        while($row2 = mysqli_fetch_array($result2))
        {
            ?> 
            <div class="col-md-4">
                <div class="thumbnail" id=<?php echo $row2[0] ?>>
                    <img src= <?php echo $row2[5] ?> alt="...">
                    <div class="caption">
                        <h3><?php echo $row2[1] ?></h3>
                        <p>Price: R<?php echo $row2[3] ?></p>
                        <p>
                           <p><a href="paymentgateway.php?id=<?php echo $row2[0] ?>" class="btn btn-primary" role="button" data-id="<?php echo $row2[0] ?>"  value="" onClick="refreshPage()" >Buy</a></p>
                       </div>
                   </div>
                   </div> <?php
               }
               ?>
           </div>

           <footer class="page-footer font-small blue">
            <div class="footer-copyright text-center py-3">© 2018 Copyright:
                <a href="https://mdbootstrap.com/education/bootstrap/"> Vending Machine Assessment</a>
            </div>
        </footer>
    </body>