<?php
session_start();
if(isset($_SESSION['currentUser']))
{
  $_SESSION['currentUser'];
}else
{
  Header("Location: index.php");
}
session_destroy();
?>

<html lang="en">
<head>
  <meta charset="utf-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

  <div class="page-header">
    <h1>Vending Machine <small>Product Management System</small></h1>
  </div>  
  <nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php">VMachine</a>
      </div>
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          <li class="dropdown">
            <a href="index.php" role="button">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div>
    <h3><u>Products listing</u></h3>
  </div>

  <table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Product Name</th>
        <th scope="col">Product Description</th>
        <th scope="col">Product Price</th>
        <th scope="col">Product Quantity</th>
      </tr>

    </thead>
    <tbody>

     <?php
     $hostname = "localhost";
     $username = "root";
     $password = "";
     $databaseName = "sbsa_vmachine";

     $connect = mysqli_connect($hostname, $username, $password, $databaseName);
     $query = "SELECT * FROM `products`";
     $result1 = mysqli_query($connect, $query);
     $result2 = mysqli_query($connect, $query);
     $dataRow = "";
     while($row2 = mysqli_fetch_array($result2))
     {

      ?> 

      <tr>
        <th scope="row"><?php echo $row2[0] ?></th>
        <td><?php echo $row2[1] ?></td>
        <td><?php echo $row2[2] ?></td>
        <td><?php echo $row2[3] ?></td>
        <td><?php echo $row2[4] ?></td>

      </tr>

    <?php }?>
  </tbody>
</table>

<footer class="page-footer font-small blue">
  <div class="footer-copyright text-center py-3">© 2018 Copyright:
    <a href="https://mdbootstrap.com/education/bootstrap/"> Vending Machine Assessment</a>
  </div>
</footer>

</body>
</html> 