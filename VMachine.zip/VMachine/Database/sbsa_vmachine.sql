-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2018 at 09:15 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sbsa_vmachine`
--

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE `currency` (
  `ID` int(11) NOT NULL,
  `Amount` double NOT NULL,
  `currencyName` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`ID`, `Amount`, `currencyName`) VALUES
(1, 0.5, NULL),
(2, 1, NULL),
(3, 2, NULL),
(4, 5, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ID` int(11) NOT NULL,
  `ProductName` varchar(255) NOT NULL,
  `ProductDesc` varchar(255) DEFAULT NULL,
  `ProdPrice` double DEFAULT NULL,
  `Quantity` int(11) NOT NULL,
  `imageUrl` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ID`, `ProductName`, `ProductDesc`, `ProdPrice`, `Quantity`, `imageUrl`) VALUES
(1, 'Lays', 'Chips', 5, 5, '/VMachine/img/Products/lays.jpeg'),
(2, 'Chomp', 'Chocolate', 6.5, 9, '/VMachine/img/Products/chomp.jpg'),
(3, 'Fanta Orange', 'Soft Drink', 8.5, 12, '/VMachine/img/Products/fanta.jpg'),
(4, 'Coca Cola', 'Soft Drink', 8.5, 6, '/VMachine/img/Products/cocacola.jpg'),
(5, 'KitKat', 'Chocolate', 6, 4, '/VMachine/img/Products/kitkat.jpeg'),
(6, 'Marie Buscuits', 'Cookies', 12, 8, '/VMachine/img/Products/Buscuit.jpg'),
(7, 'Lunch Bar', 'Chocolate', 9.5, 4, '/VMachine/img/Products/lunchbar.jpg'),
(8, 'Minute Maid', 'Soft Drink', 13.5, 11, '/VMachine/img/Products/minutemaid.jpg'),
(9, 'PS', 'Chocolate', 10, 5, '/VMachine/img/Products/PS.jpg'),
(10, 'Lays', 'Chips', 10, 0, '/VMachine/img/Products/lays.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(255) NOT NULL,
  `userID` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `userID`, `password`, `username`) VALUES
('Ben', 1, 'test123', 'assessment');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `currency`
--
ALTER TABLE `currency`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
